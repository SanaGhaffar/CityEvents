<?php include 'header.php'; ?>
    <br>
    <br>
<br>
<br>
<br>
<div class="col-lg-15 mt-5 pl-lg-5" data-aos="fade-up" data-aos-delay="200" align="center">
            <h1 style="color:red;"> About Us</h1>
          </div>
        </div>
		  <div class="col-lg-15 mt-5 pl-lg-5" data-aos="fade-up" data-aos-delay="200" align="center">

            <p>
              City Events is the online platform for the local events happening in the Kiel.
			  In the City Events users can search latest events and can filter events according to the requirement.
			  Event organizers can add the event into the website with event location, time and place. Site admin
              will approve all the events listed by event managers.
			  <br>
			  <br>
			  <br>
			  "Some people look for a beautiful place. Others make a place beautiful.” -Hazrat Inavat Khan
            </p>
          </div>
        </div>
 
<br>
<br>
<br>
<br>
<br>
<br>
<br>
<br><br>
<br>
<?php include 'footer.php'; ?>