<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url()?>vendor/jquery/jquery.min.js"></script>
<script src="<?php echo base_url()?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo base_url()?>vendor/jquery-easing/jquery.easing.min.js"></script>


  <!-- Page level plugin JavaScript-->
  <script src="<?php echo base_url()?>vendor/chart.js/Chart.min.js"></script>
  <script src="<?php echo base_url()?>vendor/datatables/jquery.dataTables.js"></script>
  <script src="<?php echo base_url()?>vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="<?php echo base_url()?>js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="<?php echo base_url()?>js/demo/datatables-demo.js"></script>
  <script src="<?php echo base_url()?>js/demo/chart-area-demo.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<script type="text/javascript" src='http://maps.google.com/maps/api/js?&key=AIzaSyC0UsNMtrx3Jj-I8N-XiocWwN1mRxb5_pI&sensor=false&libraries=places'></script>
<script src="<?php echo base_url()?>js/locationpicker.jquery.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />